1B出口 グループ管理システム
Firebase Realtime Databaseを使用。
グループ名、ステージ数、タイマーを複数端末からリアルタイム共有。
index.htmlをFirebase Hosting等で公開すれば、同じURLをiPadで開くだけで利用可能。
